<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         '0NtjFwQ+*aupR1^_@8,dp)uI/njsY%ED[$95PD$iUgk5H9Pn~YC9q3<bP)9L`S!u' );

define( 'SECURE_AUTH_KEY',  'joU02aU`E?;eOD|T$,_H]C?6@>JD0wTnVw9*gX%|PwOc&Rw@[JxQj,mCYAXj/7XE' );

define( 'LOGGED_IN_KEY',    '+yv-)}0?R9r;uPT0pCoZ api$HRG=.[<SSj*#K.!)29^Gvb0Cc-:(p/SyxPEm7:B' );

define( 'NONCE_KEY',        'm8[{sIRRpW?1#^n8ZV1.:/s|Y+4h8sY9,w;37<Mb<d8r!sY9f|>OAd$r;5zQH>x0' );

define( 'AUTH_SALT',        'N|!@,w3Z!]Zr&E)d5<,,DrFA &wH0-6T7:c@0tzJMmFV7ZU$I/qzR[77I?{1?&#L' );

define( 'SECURE_AUTH_SALT', 'R_,W}(OihIU4qN[jj[<`|&[/K9k]:{N&,whyrPCN94$CoLX(tU8PYuc0dm!]ow6b' );

define( 'LOGGED_IN_SALT',   '9qS*%Jr>ma;)np|%Af&Pld0MuQko1ii,*D)rDWP7]`Era),ie<`EOsmy^mKIkF(C' );

define( 'NONCE_SALT',       's+S.U|vC`a{p?_!B<H*1q7wueZd}@;e^Q{8Zl<xaTEU_3]_-kBK)x1l2|;eTrV%c' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

